import React, { Component, useEffect, useState } from 'react';
import './App.css';
import Game from './gamestart.js';

class App2 extends Component {
  render() {
      const myStyle = {
          position: 'fixed',
          top: 0,
          left: 0,
          backgroundImage:
              "url('https://i.pinimg.com/originals/83/ea/58/83ea5842c1f9ff2f3a9761b6c17f3b32.gif')",
          height: "100vh",
          width: "100vw",
          zIndex: 0, //go behind App
          fontSize: "45px",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          transition: 'opacity 1s', 
      };
      return <div style={myStyle}></div>;
  }
}

const styles = {
  main: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height:'100vh',
    position: 'relative',
    zIndex: 1, 
    transition: 'opacity 1s',
  },
  customText: {
    color: 'red',
    fontSize: '75px',
    fontFamily: 'SixtyfourConvergence',
    textAlign: 'center',
  },
};

const App = ({ onStart }) => {
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    const Interaction = () => {
    setIsFading(true);
    setTimeout(() => {
      onStart();
    }, 1000);
  };

document.addEventListener('keydown', Interaction);

return() => {
  document.removeEventListener('keydown', Interaction);
};
}, []);

  return (
     <div style={{ ...styles.main, opacity: isFading ? 0 : 1}}>
      <h1 style={styles.customText}> THE CHRONICLES OF EXOPLANET EXPLORATION</h1>
      <h1 style={styles.customText}> do you know your types of planets?</h1>
      <h1 style={styles.customText}> press any key to find out!</h1>
     </div>
  );
};


export default function MyApp() {
  const [isGameStarted, setIsGameStarted] = useState(false);

  const startGame = () => {
    setIsGameStarted(true);
  };

  useEffect(() => {
    function Interaction(e) {
      console.log(e.keyCode);
    }

    document.addEventListener('keydown', Interaction);

    return () => {
      document.removeEventListener('keydown', Interaction);
    };
  }, []);

  return (
    <div>
      {isGameStarted ? (
        <Game />
      ) : (
    <>
      <App onStart={startGame}/>
      <App2 />
      </>
      )}
    </div>
  );
} 